<%-- 
    Document   : input
    Created on : 18 Apr, 2025, 10:09:52 PM
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
       
        <h2>Division and Multiplication</h2>
        <form action="output.jsp" method="get">
            <label for="a1">Enter a numbers:</label>
            <input type="text" id="a1" name="a1" required>
              <input type="text" id="b1" name="b1" required>
            <br><br>
            <input type="submit" value="Result">
        </form>
    </body>
</html>
