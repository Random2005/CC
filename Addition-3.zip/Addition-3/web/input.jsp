<%-- 
    Document   : input
    Created on : 18 Apr, 2025, 8:41:59 PM
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
         <h2>Addition of three numbers</h2>
        <form action="output.jsp" method="get">
            <label for="a1">Addition of three numbers:</label>
            <input type="text" id="a1" name="a1" required>
            <input type="text" id="b1" name="b1" required>
            <input type="text" id="c1" name="c1" required>
            <br><br>
            <input type="submit" value="Addition">
        </form>
        
    </body>
</html>
