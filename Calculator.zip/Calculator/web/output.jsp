<%-- 
    Document   : output
    Created on : 18 Apr, 2025, 9:46:37 PM
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
            <%-- start web service invocation --%><hr/>
    <%
    try {
	client.Arithmatic_Service service = new client.Arithmatic_Service();
	client.Arithmatic port = service.getArithmaticPort();
	 // TODO initialize WS operation arguments here
	int a = Integer.parseInt(request.getParameter("a1"));
	int b = Integer.parseInt(request.getParameter("b1"));
	// TODO process result here
	java.lang.String result = port.arithmaticOp(a, b);
	out.println("Result = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>

        
    </body>
</html>
