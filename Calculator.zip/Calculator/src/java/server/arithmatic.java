/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Admin
 */
@WebService(serviceName = "arithmatic")
public class arithmatic {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "arithmaticOp")
    public String arithmaticOp(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        //TODO write your implementation code here:
        return "The result for addition :" +(a+b)+ " and subtraction is :" +(a-b);
    }

   
}
