<%-- 
    Document   : output
    Created on : 18 Apr, 2025, 9:17:17 PM
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
           <%-- start web service invocation --%><hr/>
    <%
    try {
	client.CurrencyConverter_Service service = new client.CurrencyConverter_Service();
	client.CurrencyConverter port = service.getCurrencyConverterPort();
	 // TODO initialize WS operation arguments here
	double a = Double.parseDouble(request.getParameter("a1"));
	// TODO process result here
	java.lang.String result = port.inrtoDollar(a);
	out.println("Result = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>

        
    </body>
</html>
