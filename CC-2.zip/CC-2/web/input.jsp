<%-- 
    Document   : input
    Created on : 18 Apr, 2025, 9:17:05 PM
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Currency Converter</h2>
        <form action="output.jsp" method="get">
            <label for="a1">Indian rs:</label>
            <input type="text" id="a1" name="a1" required>
            <br><br>
            <input type="submit" value="Convert">
        </form>
        
    </body>
</html>
