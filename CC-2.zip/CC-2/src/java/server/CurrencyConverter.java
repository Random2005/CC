/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Admin
 */
@WebService(serviceName = "CurrencyConverter")
public class CurrencyConverter {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "InrtoDollar")
    public String InrtoDollar(@WebParam(name = "a") double a) {
        //TODO write your implementation code here:
        return "The Indian rs in Dollar is :"+(a/83.7);
    }

  
}
