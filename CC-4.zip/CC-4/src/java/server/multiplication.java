/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Admin
 */
@WebService(serviceName = "multiplication")
public class multiplication {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "multi")
    public String multi(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        //TODO write your implementation code here:
        return "The multiplication of two number is :"+(a*b);
    }

   
}
